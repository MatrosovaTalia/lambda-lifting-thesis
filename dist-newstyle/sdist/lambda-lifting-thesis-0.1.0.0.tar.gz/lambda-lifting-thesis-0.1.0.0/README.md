# lambda-lifting-thesis
The source code for the Bachelor thesis: Lambda lifting via data parallel syntax tree representation in Haskell.

[The work is in progress].

The thesis main goal is to implement a parallell lambda lifting algorithm for a toy (Python-based) programming language (toypy). The thesis is based on Aaron Hsu paper "The Key to a data Parallel Compiler".
The examples of the toypy language may be foun in the "examples" foldeer. Haskell implementation is in "implementation folder".
